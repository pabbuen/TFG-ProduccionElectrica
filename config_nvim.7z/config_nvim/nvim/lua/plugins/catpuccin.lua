return {
    lazy = false,
    "catppuccin/nvim", 
    name = "catppuccin", 
    priority = 1000 ,
}

